<?xml version="1.0" encoding="UTF-8"?>
<!-- Licensed Materials - Property of IBM -->
<!-- Copyright IBM Corporation 2017, 2024. All Rights Reserved. -->
<!-- US Government Users Restricted Rights - Use, duplication or disclosure -->
<!-- restricted by GSA ADP Schedule Contract with IBM Corp. -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:dp="http://www.datapower.com/extensions"
	exclude-result-prefixes="dp xsl"
	extension-element-prefixes="dp">
	
	<xsl:output method="html" version="4.0" encoding="iso-8859-1" indent="yes" doctype-public="-//W3C//DTD HTML 4.01//EN"/>
	
	<dp:summary xmlns="">
		<operation>xform</operation>
		<description>Handle backside errors and return a meaningful HTML page.</description>
	</dp:summary>	
	
	<!-- custom error stylesheet for the backside WS-Proxies -->
	<xsl:template match="/">
		<!-- -->
		<!-- Fetch the error information captured by On-Error rule -->
		<!-- Also capture the x-dp-response-code in case this rule has been executed by a backend failure -->
		<!-- -->
		<xsl:variable name="errorResponse" select="dp:variable('var://context/errorContext/errorResponse')" />
		<xsl:variable name="errorReason" select="dp:variable('var://context/errorContext/errorReason')" />
		<xsl:variable name="x-dp-response-code" select="normalize-space(dp:response-header('x-dp-response-code'))" />
		<xsl:variable name="error-headers" select="dp:variable('var://service/error-headers')" />
		<xsl:variable name="error-message" select="dp:variable('var://service/error-message')" />
		<xsl:variable name="conformance-error-message" select="dp:variable('var://local/_internal/ap_conformance/results_err_msg')" />
		<xsl:variable name="error-code" select="dp:variable('var://service/error-code')" />
		<xsl:variable name="error-subcode" select="dp:variable('var://service/error-subcode')" />
		<xsl:variable name="interface" select="dp:variable('var://service/URI')" />
		<xsl:variable name="processor-name" select="dp:variable('var://service/processor-name')" />
		<xsl:variable name="processor-type" select="dp:variable('var://service/processor-type')" />
		
		<!-- Determine whether the error is on a request or response -->
		<xsl:variable name="rmode" select="dp:variable('var://service/response-mode')" />

		<!-- -->
		<xsl:message dp:priority="info">
		    <xsl:value-of select="string('render-html-error.xsl info: ')" />
			<xsl:value-of select="concat('errorResponse=', $errorResponse)" />
			<xsl:value-of select="concat(', errorReason=', $errorReason)" />
			<xsl:value-of select="concat(', errorMessage=', $error-message)" />
			<xsl:value-of select="concat(', x-dp-response-code=', $x-dp-response-code)" />
			<xsl:value-of select="concat(', response-mode=', $rmode)" />
		</xsl:message>
		<!-- -->
		<!-- When x-dp-response-code is set, a DP Service on the backend has failed -->
		<!-- If so, use its code, else get the code set by the error rule -->
		<!-- When errorResponse is set, a On-Error action has been fired -->
		<!-- When errorResponse is equal 'Rejected', there was no match for the client to server rule -->
		<!-- Otherwise we assume an invalid interface has been called -->
		<!-- -->
		<xsl:variable name="protocolResponse">
			<xsl:choose>
				<!-- Event Code 0x01130006 and 0x01130007 - Failed to establish backside connection -->
				<!-- No network connection between the device and the backside server could be established. -->
				<xsl:when test="$error-code='0x01130006'">
					<xsl:value-of select="concat('Connection Error: ', $error-message)" />
				</xsl:when>
				<xsl:when test="$error-code='0x01130007'">
					<xsl:value-of select="concat('Connection Error: ', $error-message)" />
				</xsl:when>
				<!-- Event Code 0x0113001c - Connection error -->
				<!-- An unexepected network hangup has occurred, forcing the cancellation of this transaction. -->
				<xsl:when test="$error-code='0x0113001c'">
					<xsl:value-of select="concat('Connection Error: ', $error-message)" />
				</xsl:when>
				<!-- rejected by AAA policy or no matching rule found -->
				<xsl:when test="starts-with($error-message, 'Rejected')">
					<xsl:value-of select="'Access denied!'" />
				</xsl:when>
				<!-- Event Code 0x01d30003 - Schema Validation Error -->
				<!-- The schema validation in the Validate processing step failed. -->
				<xsl:when test="$error-subcode='0x01d30003'">
					<xsl:choose>
						<!-- back end server sent a response -->
						<xsl:when test="$x-dp-response-code!=''">
							<xsl:value-of select="concat('Response schema validation failed! - ', $conformance-error-message)" />
						</xsl:when>
						<!-- request validation failed -->
						<xsl:otherwise>
							<xsl:value-of select="concat('Request schema validation failed! - ', $conformance-error-message)" />
						</xsl:otherwise>
					</xsl:choose>
				</xsl:when>
				<!-- any other error message -->
				<xsl:when test="$error-message!=''">
					<xsl:choose>
						<!-- back end server sent a response -->
						<xsl:when test="$x-dp-response-code!=''">
							<xsl:value-of select="concat('Response Error: ', $error-message)" />
						</xsl:when>
						<!-- request validation failed -->
						<xsl:otherwise>
							<xsl:value-of select="concat('Reqeust Error: ', $error-message)" />
						</xsl:otherwise>
					</xsl:choose>
				</xsl:when>
				<!-- empty error message i.e. unexpected error -->
				<xsl:otherwise>
					<xsl:choose>
						<!-- back end server sent a response -->
						<xsl:when test="$x-dp-response-code!=''">
							<xsl:value-of select="concat('Unexpected error occurred while processing the response! [', $error-code, '-', $error-subcode, ']')" />
						</xsl:when>
						<!-- request validation failed -->
						<xsl:otherwise>
							<xsl:value-of select="concat('Unexpected error occurred! [', $error-code, '-', $error-subcode, ']')" />
						</xsl:otherwise>
					</xsl:choose>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		
		<!-- -->
		<!-- Set the services Protocol Response -->
		<!-- -->
		<dp:set-variable name="'var://service/error-protocol-response'" value="$protocolResponse" />
		<xsl:message>
			<xsl:value-of select="concat('var://service/error-protocol-response set to ', $protocolResponse)" />
		</xsl:message>		 
		
		<!-- -->
		<!-- Set HTTP Status Code -->
		<!-- -->
		<dp:set-variable name="'var://service/error-protocol-response'" value="'404'" />
		<dp:set-variable name="'var://service/error-protocol-reason-phrase'" value="'Not Found'" />
		
		<!-- -->
		<!-- Set Content Type -->
		<!-- --> 
		<dp:append-http-response-header name="'Content-Type'" value="'text/html;charset=ISO-8859-1'"/>
		<dp:append-http-response-header name="'Connection'" value="'Keep-Alive'"/>
		<dp:append-http-response-header name="'Transfer-Encoding'" value="'chunked'"/>
		
		<!-- dp:freeze-headers/ -->
		
		<!-- -->
		<!-- Get information about the transaction -->
		<!-- -->
		<xsl:variable name="transaction-client" select="dp:variable('var://service/transaction-client')" />
		<xsl:variable name="transaction-id" select="dp:variable('var://service/transaction-id')" />
		<xsl:variable name="URL-in" select="dp:variable('var://service/URL-in')" />
		<xsl:variable name="URL-out" select="dp:variable('var://service/URL-out')" />
		<!-- -->
		<!-- Produce a HTML page with all the acquired information -->
		<!-- -->
		<html>
			<head>
				<title>DataPower Log Viewer Error Page [TEST]</title>
			</head>
			<body>
				<h1>Sorry, an error occurred :-(</h1>
				<h2><xsl:value-of select="$protocolResponse" /></h2>
					<h3>Transaction Info:</h3>
					<table border="1">
					<tr><td>Transaction ID = </td><td><xsl:value-of select="$transaction-id" /></td></tr>
					<tr><td>Transaction Client = </td><td><xsl:value-of select="$transaction-client" /></td></tr>
					<tr><td>URL-in = </td><td><xsl:value-of select="$URL-in" /></td></tr>
					<tr><td>URL-out = </td><td><xsl:value-of select="$URL-out" /></td></tr>
					<tr><td>Processor Name = </td><td><xsl:value-of select="$processor-name" /></td></tr>
					<tr><td>Processor Type = </td><td><xsl:value-of select="$processor-type" /></td></tr>
					</table>
					<xsl:variable name="errorInfo" select="dp:variable('var://context/errorContext/errorInfo')" />
					<h3>Details:</h3>
					<table border="1">
					<tr><td>Error Info = </td><td><pre><xsl:copy-of select="$errorInfo" /></pre></td></tr>
					</table>
			</body>
		</html>
	</xsl:template>
</xsl:stylesheet>

