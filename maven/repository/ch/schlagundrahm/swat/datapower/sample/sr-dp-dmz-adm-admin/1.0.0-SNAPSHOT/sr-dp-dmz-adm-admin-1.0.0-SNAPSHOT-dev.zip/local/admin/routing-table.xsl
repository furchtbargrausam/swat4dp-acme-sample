<?xml version="1.0" encoding="UTF-8"?>
<!-- Licensed Materials - Property of IBM -->
<!-- Copyright IBM Corporation 2017. All Rights Reserved. -->
<!-- US Government Users Restricted Rights - Use, duplication or disclosure -->
<!-- restricted by GSA ADP Schedule Contract with IBM Corp. -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions"
    xmlns:dpfunc="http://www.datapower.com/extensions/functions" xmlns:func="http://exslt.org/functions" xmlns:date="http://exslt.org/dates-and-times"
    xmlns:regexp="http://exslt.org/regular-expressions" xmlns:str="http://exslt.org/strings" extension-element-prefixes="dp func regexp"
    exclude-result-prefixes="dp dpfunc func date str regexp">

    <xsl:output method="xml" version="1.0" encoding="UTF-8" />

    <xsl:template match="/">
        <xsl:message dp:priority="debug">
            Enter the dynamic routing main template (routing.xsl)
        </xsl:message>

        <!-- Get the incoming Host -->
        <xsl:variable name="incomingHost" select="dp:http-request-header('Host')" />
        <!-- xsl:variable name="incomingHost" select="substring-before(concat(dp:http-request-header('Host'),':'),':')" / -->

        <!-- Get the incoming URI -->
        <xsl:variable name="incomingURI" select="dp:variable('var://service/URI')" />

        <xsl:message dp:priority="debug">
            <xsl:value-of select="concat('incomingHost=', $incomingHost, '; incomingURI=', $incomingURI)" />
        </xsl:message>

        <!-- Get the routing information from the routing doc -->
        <!-- xsl:variable name="sourceHost" select="routing-destinations/source-host[@host=$incomingHost]" / -->
        <xsl:variable name="sourceHost" select="routing-destinations/source-host[regexp:test($incomingHost,@host)]" />

        <xsl:message dp:priority="debug">
            Source Host is set to:
            <xsl:value-of select="$sourceHost/@host" />
        </xsl:message>

        <xsl:if test="string($sourceHost) = ''">
            <!-- handle default, send error?? -->
            <xsl:call-template name="send-error">
                <xsl:with-param name="ErrorMsg">
                    No destination found for Host
                    <xsl:value-of select="$incomingHost" />
                    , abort.
                </xsl:with-param>
            </xsl:call-template>
        </xsl:if>

        <!-- xsl:message dp:priority="debug">Running through the elements: <xsl:copy-of select="$sourceHost" /> </xsl:message -->

        <xsl:for-each select="$sourceHost/source-uri">
            <xsl:sort select="@order" />
            <!-- xsl:message dp:priority="debug">Element is <xsl:copy-of select="." /> </xsl:message -->
            <xsl:choose>
                <xsl:when test="dp:variable('var://context/dispatch/routing/isURIMatching') != ''">
                    <!-- do nothing as we already found a match -->
                </xsl:when>
                <xsl:when test="@uri-type='start'">
                    <xsl:variable name="isURIMatching" select="starts-with($incomingURI,@uri)" />
                    <xsl:if test="$isURIMatching">
                        <xsl:message dp:priority="debug">
                            <xsl:value-of select="concat('Found a starting match: ', $incomingHost, ', ', @uri)" />
                        </xsl:message>
                        <dp:set-variable name="'var://context/dispatch/routing/isURIMatching'" value="$isURIMatching" />
                        <xsl:apply-templates select="destination" />
                    </xsl:if>
                </xsl:when>
                <xsl:when test="@uri-type='exact'">
                    <xsl:variable name="isURIMatching" select="$incomingURI=@uri" />
                    <xsl:if test="$isURIMatching">
                        <xsl:message dp:priority="debug">
                            <xsl:value-of select="concat('Found an exact match: ', $incomingHost, ', ', @uri)" />
                        </xsl:message>
                        <dp:set-variable name="'var://context/dispatch/routing/isURIMatching'" value="$isURIMatching" />
                        <xsl:apply-templates select="destination" />
                    </xsl:if>
                </xsl:when>
                <xsl:when test="@uri-type='regexp'">
                    <xsl:variable name="isURIMatching" select="regexp:test($incomingURI,@uri,'g')" />
                    <xsl:if test="regexp:test($incomingURI,@uri,'g')">
                        <xsl:message dp:priority="debug">
                            <xsl:value-of select="concat('Found a regexp match: ', $incomingHost, ', ', @uri)" />
                        </xsl:message>
                        <dp:set-variable name="'var://context/dispatch/routing/isURIMatching'" value="$isURIMatching" />
                        <xsl:apply-templates select="destination" />
                    </xsl:if>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:message dp:priority="debug">
                        No known URI-Type for element defined, abort.
                    </xsl:message>
                    <xsl:call-template name="send-error">
                        <xsl:with-param name="ErrorMsg">
                            No destination found for Host
                            <xsl:value-of select="concat($incomingHost, $incomingURI)" />
                            , abort.
                        </xsl:with-param>
                    </xsl:call-template>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:for-each>

        <xsl:variable name="match-found" select="dp:variable('var://context/dispatch/routing/isURIMatching')" />
        <xsl:message dp:priority="debug">
            <xsl:value-of select="concat('match-found = ', $match-found)" />
        </xsl:message>
        <xsl:if test="string($match-found) = ''">
            <!-- handle default, send error?? -->
            <xsl:call-template name="send-error">
                <xsl:with-param name="ErrorMsg">
                    <xsl:value-of select="concat('unknown URL ', $incomingHost, $incomingURI)" />
                </xsl:with-param>
            </xsl:call-template>
        </xsl:if>
    </xsl:template>

    <xsl:template match="destination">
        <xsl:choose>
            <xsl:when test="@uri-type='fixed'">
                <!-- For fixed uri-type, we can directly use the given URL -->
                
                <xsl:variable name="isRedirect" select="redirect/text()='true'" />
                <xsl:variable name="isSSL" select="ssl/text()='true'" />
                
                <xsl:choose>
                    <xsl:when test="$isRedirect">
                        <xsl:variable name="redirectURL" select="targetURL/text()" />
                        <!-- Handle the redirect! -->
                        <xsl:message dp:priority="debug">
                            Set a redirect (302):
                            <xsl:value-of select="$redirectURL" />
                        </xsl:message>
                        <dp:set-response-header name="'Location'" value="$redirectURL" />
                        <dp:set-http-response-header name="'x-dp-response-code'" value="'302 Found'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:choose>
                            <xsl:when test="$isSSL">
                                <xsl:variable name="sslIDpur" select="sslID/text()" />
                                <xsl:variable name="sslID" select="concat('client:',$sslIDpur)" />
                                <xsl:message dp:priority="debug">
                                    Calling an SSL Target with SSLProxyProfile
                                    <xsl:value-of select="$sslID" />
                                    .
                                </xsl:message>
                                <dp:set-variable name="'var://service/routing-url-sslprofile'" value="$sslID" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:message dp:priority="debug">
                                    Calling an non-SSL Target.
                                </xsl:message>
                            </xsl:otherwise>
                        </xsl:choose>
                        <xsl:variable name="backendURL" select="targetURL/text()" />
                        <dp:set-variable name="'var://service/routing-url'" value="$backendURL" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="@uri-type='same'">
                <!-- Now, we have either an exact or a match destination, but we are routing to the same uri, so this can not be a redirect -->
                <xsl:variable name="proto" select="targetProto/text()" />
                <xsl:variable name="host" select="targetHost/text()" />
                <xsl:variable name="port" select="targetPort/text()" />
                <xsl:variable name="isRedirect" select="redirect/text()='true'" />
                <xsl:variable name="isSSL" select="ssl/text()='true'" />

                <xsl:variable name="incomingURI" select="dp:variable('var://service/URI')" />

                <xsl:choose>
                    <xsl:when test="$isRedirect">
                        <xsl:variable name="redirectURL" select="concat($proto,'://',$host,':',$port,$incomingURI)" />
                        <!-- Handle the redirect! -->
                        <xsl:message dp:priority="debug">
                            Set a redirect (302):
                            <xsl:value-of select="$redirectURL" />
                        </xsl:message>
                        <dp:set-response-header name="'Location'" value="$redirectURL" />
                        <dp:set-http-response-header name="'x-dp-response-code'" value="'302 Found'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:variable name="proxyURL" select="concat($proto,'://',$host,':',$port,$incomingURI)" />
                        <!-- Handle the proxy! -->
                        <xsl:message dp:priority="debug">
                            Set a proxy to:
                            <xsl:value-of select="$proxyURL" />
                        </xsl:message>
                        <xsl:choose>
                            <xsl:when test="$isSSL">
                                <xsl:variable name="sslIDpur" select="sslID/text()" />
                                <xsl:variable name="sslID" select="concat('client:',$sslIDpur)" />
                                <xsl:message dp:priority="debug">
                                    Calling an SSL Target with SSLProxyProfile
                                    <xsl:value-of select="$sslID" />
                                    .
                                </xsl:message>
                                <dp:xset-target host="$host" port="$port" ssl="true()" sslid="{$sslID}" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:message dp:priority="debug">
                                    Calling an non-SSL Target.
                                </xsl:message>
                                <dp:xset-target host="$host" port="$port" ssl="false()" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="@uri-type='regexp'">
                <!-- For this type, we have either a redirect or a proxy! -->
                <xsl:variable name="proto" select="targetProto/text()" />
                <xsl:variable name="host" select="targetHost/text()" />
                <xsl:variable name="port" select="targetPort/text()" />
                <xsl:variable name="uriPattern" select="uriPattern/text()" />
                <xsl:variable name="uriReplace" select="uriReplace/text()" />
                <xsl:variable name="isRedirect" select="redirect/text()='true'" />
                <xsl:variable name="isSSL" select="ssl/text()='true'" />
                <xsl:variable name="isFile" select="fileLocation/text() != ''" />
                <xsl:variable name="location" select="fileLocation/text()" />

                <!-- regex to replace incomingURI with patternURI -->
                <xsl:variable name="incomingURI" select="dp:variable('var://service/URI')" />
                <xsl:variable name="targetURI" select="regexp:replace($incomingURI,$uriPattern,'g',$uriReplace)" />
                <xsl:message dp:priority="debug">
                    Ran replace
                    <xsl:value-of select="concat($incomingURI,',',$uriPattern,',',$uriReplace)" />
                    with the result:
                    <xsl:value-of select="$targetURI" />
                </xsl:message>

                <xsl:choose>
                    <xsl:when test="$isRedirect">
                        <xsl:variable name="redirectURL" select="concat($proto,'://',$host,':',$port,$targetURI)" />
                        <!-- Handle the redirect! -->
                        <xsl:message dp:priority="debug">
                            Set a redirect (302):
                            <xsl:value-of select="$redirectURL" />
                        </xsl:message>
                        <dp:set-response-header name="'Location'" value="$redirectURL" />
                        <dp:set-http-response-header name="'x-dp-response-code'" value="'302 Found'" />
                    </xsl:when>
                    <xsl:when test="$isFile">

                        <xsl:variable name="proxyURL" select="concat($location, '://', $targetURI)" />
                        <!-- Handle the proxy! -->
                        <xsl:message dp:priority="debug">
                            Set a proxy to:
                            <xsl:value-of select="$proxyURL" />
                        </xsl:message>
                        <dp:set-variable name="'var://service/URI'" value="$targetURI" />
                        <dp:set-variable name="'var://service/routing-url'" value="$proxyURL" />


                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:variable name="proxyURL" select="concat($proto,'://',$host,':',$port,$targetURI)" />
                        <!-- Handle the proxy! -->
                        <xsl:message dp:priority="debug">
                            Set a proxy to:
                            <xsl:value-of select="$proxyURL" />
                        </xsl:message>
                        <dp:set-variable name="'var://service/URI'" value="$targetURI" />
                        <xsl:choose>
                            <xsl:when test="$isSSL">
                                <xsl:variable name="sslID" select="sslID/text()" />
                                <xsl:message dp:priority="debug">
                                    Calling an SSL Target with SSLProxyProfile
                                    <xsl:value-of select="$sslID" />
                                    .
                                </xsl:message>
                                <dp:xset-target host="$host" port="$port" ssl="true()" sslid="{$sslID}" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:message dp:priority="debug">
                                    Calling an non-SSL Target.
                                </xsl:message>
                                <dp:xset-target host="$host" port="$port" ssl="false()" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
        </xsl:choose>
    </xsl:template>

    <xsl:template name="send-error">
        <xsl:param name="ErrorMsg" />
        <dp:set-variable name="'var://context/GTW/reject-reason'" value="string($ErrorMsg)" />
        <dp:reject>
            <xsl:copy-of select="$ErrorMsg" />
        </dp:reject>
    </xsl:template>

</xsl:stylesheet>