/*
    Licensed Materials - Property of IBM
    IBM WebSphere DataPower Appliances
    Copyright IBM Corporation 2017. All Rights Reserved.
    US Government Users Restricted Rights - Use, duplication or disclosure
    restricted by GSA ADP Schedule Contract with IBM Corp.

    Date created: 06.01.2017
    Last modified: 10.10.2017 - pierce.shah@ch.ibm.com
    Purpose: Handle common error conditions in a MPGW and return an appropriate JSON, SOAP or XHTML fault.
    Usage: use it as a GatewayScript action within an error rule
    Prerequisite: input is the either the original request or response
    
    Error Code Semantic:
    Prefix: GTW
    5-digit numeric code where the last 3 digits are an equivalent to the HTTP error codes
    the first 2 digits are reserved for future use
 */

var hm = require('header-metadata');
var service = require('service-metadata');

var errorProtocolResponse = service.errorProtocolResponse;
console.debug('errorProtocolResponse: %1$s', errorProtocolResponse);

// HTTP Method
var protocolMethod = service.protocolMethod;

// Headers
var origHeaders = hm.original.get();
console.debug('origHeaders: %1$s', origHeaders);

// Retrieve client IP address
var clientIP = hm.original.get('X-Client-IP');

// Also can get the status code and reason phrase off the wire
var originalStatusCode = hm.original.statusCode;
var originalReasonPhrase = hm.original.reasonPhrase;

// create a context named `errorContext` if not exist
var errorCtx = session.name('errorContext') || session.createContext('errorContext');
var rmode = errorCtx.getVar('responseMode');

/*
 * Set the services Protocol Response
 */
// create a context named `GTW` if it does not exist yet
var gtwCtx = session.name('GTW') || session.createContext('GTW');

session.input.readAsBuffer(function(readAsBufferError, input) {
    if (readAsBufferError) {
        // handle error
        session.output.write(readAsBufferError.errorMessage);
    } else {

        // Retrieve a single current header value. Read the
        // content-type header (case insensitive).
        // If there are multiple headers with the same name
        // (for example, set-cookie), then only
        // the first header is returned as a string.
        var contentTypeRaw = hm.original.get('content-type');
        var contentType = "";
        
        if (typeof(contentTypeRaw) != 'undefined'  && contentTypeRaw != null && contentTypeRaw != "") {
            contentType = contentTypeRaw.split(";")[0];
        }
        
        var acceptType = hm.original.get('accept');

        // create an appropriate GTWE error response message based on the error
        // code
        var protocolResponse = _generateProtocolResponse();

        switch (service.errorCode) {
        case "0x01130006":
            hm.current.statusCode = "400 Bad Request";
            hm.response.statusCode = "400 Bad Request";
            session.output.write(_getErrorResponse(acceptType, contentType, protocolResponse));
            break;
        case "0x00d30003":
            // TODO: should we better use 404 instead of 403 in case of rejects?
            hm.current.statusCode = "403 Forbidden";
            hm.response.statusCode = "403 Forbidden";
            session.output.write(_getErrorResponse(acceptType, contentType, protocolResponse));
            break;
        default:
            service.mpgw.skipBackside = true;
            hm.response.statusCode = "500 Internal Error";
            hm.current.statusCode = "500 Internal Error";
            session.output.write(_getErrorResponse(acceptType, contentType, protocolResponse));
            break;
        }

    }
});

/**
 * "private method" to return the appropriate error format
 * 
 * @param acceptType -
 *            original Accept header
 * @param contentType -
 *            original Content-Type header
 * @param protocolResponse -
 *            GTW error message
 * @returns {string|*} - error response
 * @private
 */
var _getErrorResponse = function(acceptType, contentType, protocolResponse) {
    
    console.debug('_getErrorResponse(acceptType=%1$s, contentType=%2$s, protocolResponse)', acceptType, contentType);
    
    // we primarily use the content-type header instead of the accept header for simplicity
    // proper accept header with precedence handling would be quite complicated
    if (contentType == '') {
        contentType = acceptType;
    } else if (protocolMethod == 'GET') {
        contentType = acceptType;
    }

    console.debug('using %1$s to determine the error response format', contentType);

    switch (contentType) {
    case "application/json":
        hm.response.set("content-type", "application/json; charset=UTF-8");

        // JSON format
        var jsonResult = {
            "status" : protocolResponse,
            "message" : service.errorMessage,
            "client-ip" : clientIP,
            "url-in" : new String(service.URLIn),
            "url-out" : new String(service.URLOut),
            "gtid" : service.globalTransactionId,
            "errorCode" : service.errorCode
        };

        return jsonResult;
        break;
    case "application/xml":
        hm.response.set("content-type", "application/xml; charset=UTF-8");

        // XML format
        var xmlResult = "<gateway-error>"
                        + "<error-message>" + protocolResponse + "</error-message>" + "<error-details>" + "<client-ip>" + clientIP
                        + "</client-ip>" + "<url-in>" + new String(service.URLIn) + "</url-in>" + "<gtid>" + service.globalTransactionId
                        + "</gtid>" + "</error-details>" + "</gateway-error>";

        return xmlResult;
        break;
    case "application/soap+xml":
        hm.response.set("content-type", "application/soap+xml; charset=UTF-8");

        // determine whether it was a SOAP or a simple XML call
        var clientSoapVersion = service.wsm.frontProtocol;
        var isSOAPAction = hm.original.get('SOAPAction');
        console.debug("check for SOAP: version=%1$s, action=%2$s", clientSoapVersion, isSOAPAction);

        // SOAP v1.2 format
        var soap12Result = _generateSOAPFault(clientSoapVersion, protocolResponse);

        return soap12Result;
        break;
    case "text/xml":
        hm.response.set("content-type", "text/xml; charset=UTF-8");

        // determine whether it was a SOAP or a simple XML call
        var clientSoapVersion = service.wsm.frontProtocol;
        var isSOAPAction = hm.original.get('SOAPAction');
        console.debug("check for SOAP: version=%1$s, action=%2$s", clientSoapVersion, isSOAPAction);

        if (isSOAPAction) {
            // SOAP format
            var soapResult = _generateSOAPFault(clientSoapVersion, protocolResponse);
            return soapResult;
        } else {
            var xmlResult = "<gateway-error>"
                            + "<error-message>" + protocolResponse + "</error-message>" + "<error-details>" + "<client-ip>" + clientIP
                            + "</client-ip>" + "<url-in>" + new String(service.URLIn) + "</url-in>" + "<gtid>" + service.globalTransactionId
                            + "</gtid>" + "</error-details>" + "</gateway-error>";
            return xmlResult;

        }
        break;
    default:
        hm.response.set("content-type", "text/html; charset=UTF-8");

        // HTML5 (XHTML) format
        var htmlResult = "<!DOCTYPE html>"
                         + "<html xmlns='http://www.w3.org/1999/xhtml'>" 
                         + "<head>"
                         + "<title>Access Error</title>"
                         + "<meta http-equiv='Content-Type' content='application/xhtml+xml; charset=UTF-8' />" 
                         + "</head>"
                         + "<body>"
                         + "<h2>Gateway Error</h2>" + "<P />" 
                         + "<h3>" + protocolResponse + "</h3>"
                         + "<p>GTID: " + service.globalTransactionId + "</p>" + "</body>"
                         + "<p>" + new Date() + "</p>"
                         + "</html>";
        return htmlResult;
        break;
    }
};

/**
 * "private method" to return the appropriate GTWE error message
 * 
 * @returns {string|*} - protocol response message
 * @private
 */
var _generateProtocolResponse = function() {

    console.debug("generate protocol response for error code [%1$s]", service.errorCode);

    var protocolResponse = "GTWE00900";

    switch (service.errorCode) {
    case "0x01130006":
        /*
         * Event Code 0x01130006 and 0x01130007 - Failed to establish backside
         * connection No network connection between the device and the backside
         * server could be established.
         */
        protocolResponse = "GTWE00503: " + service.errorMessage;
        break;
    case "0x01130007":

        protocolResponse = "GTWE00503: " + service.errorMessage;
        break;

    case "0x0113001c":
        /*
         * Event Code 0x0113001c - Connection error An unexpected network hangup
         * has occurred, forcing the cancellation of this transaction.
         */
        protocolResponse = "GTWE00502: " + service.errorMessage;
        break;
    case "0x80e0062e":
        // Connection timeout
        protocolResponse = "GTWE00504: Timeout - " + service.errorMessage;
        break;
    case "0x00230001":
        // Dynamic execution error
        switch (service.errorSubcode) {
        case "0x01d30003":
            if (rmode == 2) {
                // back end server sent a response
                protocolResponse = "GTWE00502: Response schema validation failed! - " + service.errorMessage.replace('<', '&lt;');
            } else {
                protocolResponse = "GTWE00400: Request schema validation failed! - " + service.errorMessage.replace('<', '&lt;');
            }
            break;
        default:
            if (rmode == 2) {
                // back end server sent a response
                protocolResponse = "GTWE00502: Unexpected error occurred! [" + service.errorCode + "-" + service.errorSubcode + "]";
            } else {
                // back end server did NOT send a response

                protocolResponse = "GTWE00500: Unexpected error occurred! [" + service.errorCode + "-" + service.errorSubcode + "]";
            }
            break;
        }
        break;
    case "0x01d30003":
        /*
         * Event Code 0x01d30003 - Schema Validation Error The schema validation
         * in the Validate processing step failed.
         */
        if (rmode == 2) {
            // back end server sent a response
            protocolResponse = "GTWE00502: Response schema validation failed! - " + service.errorMessage.replace('<', '&lt;');
        } else {
            protocolResponse = "GTWE00400: Request schema validation failed! - " + service.errorMessage.replace('<', '&lt;');
        }
        break;
    case "0x00d30003":
        /*
         * rejected by AAA policy or no matching rule found
         */
        switch (service.errorSubcode) {
        case "0x01d30002":
            protocolResponse = "GTWE00403: Unauthorized access!";
            break;
        default:
            if (gtwCtx.getVar('reject-reason')) {
                protocolResponse = "GTWE00404: " + gtwCtx.getVar('reject-reason');
            } else {
                protocolResponse = "GTWE00403: Invalid service interface!";
            }
        }
        break;
    default:
        // empty error message i.e. unexpected error

        if (rmode == 2) {
            // back end server sent a response
            protocolResponse = "GTWE00500: Unexpected error occurred! [" + service.errorCode + "-" + service.errorSubcode + "]";
        } else {
            // back end server did NOT send a response

            protocolResponse = "GTWE00500: Unexpected error occurred! [" + service.errorCode + "-" + service.errorSubcode + "]";
        }
        break;
    }

    // set/get/delete variable on the named context
    gtwCtx.setVar('error-protocol-response', protocolResponse);
    console.info("'var://service/GTW/error-protocol-response' set to %1$s", protocolResponse);

    return protocolResponse;

};

/**
 * "private method" to generate a SOAP fault message
 * 
 * @param soapVersion -
 *            SOAP version to use [1.1|1.2]
 * @param protocolResponse -
 *            GTW error message
 * @returns {string|*} - SOAP fault
 * @private
 */
var _generateSOAPFault = function(soapVersion, protocolResponse) {

    var soapFault = "";
    switch (soapVersion) {
    case "1.2":
        var actor = "soapenv12:Receiver";
        if (protocolResponse.startsWith("GTWE040")) {
            actor = "soapenv12:Sender";
        }
        soapFault = "<soapenv12:Envelope xmlns:soapenv12=\"http://www.w3.org/2003/05/soap-envelope\">"
                    + "<soapenv12:Body>" + "<soapenv12:Fault>"

                    + "<soapenv12:Code>" + "<soapenv12:Value>"
                    + actor
                    + "</soapenv12:Value>"
                    + "</soapenv12:Code>"

                    + "<soapenv12:Reason>"
                    + "<soapenv12:Text xml:lang=\"en-US\">"
                    + protocolResponse
                    + "</soapenv12:Text>"
                    + "</soapenv12:Reason>"

                    + "<soapenv12:Node>"
                    + new String(service.URI)
                    + "</soapenv12:Node>"

                    + "<soapenv12:Detail>"
                    + "<transactionInfo>"
                    + "<client-ip>"
                    + clientIP
                    + "</client-ip>"
                    + "<URL-in>"
                    + new String(service.URLIn)
                    + "</URL-in>"
                    + "<URL-out>"
                    + new String(service.URLOut)
                    + "</URL-out>"
                    + "<gtid>"
                    + service.globalTransactionId + "</gtid>" + "</transactionInfo>" + "</soapenv12:Detail>"

                    + "</soapenv12:Fault>" + "</soapenv12:Body>" + "</soapenv12:Envelope>";

        break;
    default:
        var actor = "soapenv:Server";
        if (protocolResponse.startsWith("GTWE040")) {
            actor = "soapenv:Client";
        }
        soapFault = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"
                    + "<soapenv:Body>" + "<soapenv:Fault>" + "<faultcode>"
                    + actor
                    + "</faultcode>"
                    + "<faultstring>"
                    + protocolResponse
                    + "</faultstring>"
                    + "<detail>"
                    + "<client-ip>"
                    + clientIP
                    + "</client-ip>"
                    + "<URL-in>"
                    + new String(service.URLIn)
                    + "</URL-in>"
                    + "<URL-out>"
                    + new String(service.URLOut)
                    + "</URL-out>"
                    + "<gtid>"
                    + service.globalTransactionId
                    + "</gtid>"
                    + "</detail>"
                    + "</soapenv:Fault>"
                    + "</soapenv:Body>"
                    + "</soapenv:Envelope>";

    }

    return soapFault;
};
