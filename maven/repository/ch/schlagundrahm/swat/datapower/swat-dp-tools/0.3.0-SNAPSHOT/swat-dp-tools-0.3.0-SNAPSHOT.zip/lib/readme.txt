######################################################################
#                            S w a t 4 D P                           #
#                           ---------------                          #
#     schlag&rahm WebSphere Administration Toolkit for DataPower     #
#                                                                    #
#                      List of additonal Ant libraries               #
#                                                                    #
# Author: pshah@schlagundrahm.ch                                     #
# Copyright (c) 2013 schlag&rahm AG                                  #
# All rights reserved.                                               #
#                                                                    #
# http://www.schlagundrahm.ch                                        #
#                                                                    #
######################################################################

[1]  ant-flaka-1.02.02.jar          http://code.google.com/p/flaka/downloads
[2]  antform-2.0.jar                http://antforms.sourceforge.net/
[3]  ml-ant-http-1.1.3.jar          http://code.google.com/p/missing-link/
[4]  saxon9he.jar                   http://saxon.sourceforge.net/
[5]  xmltask-v1.16.1.jar            http://www.oopsconsultancy.com/software/xmltask/
