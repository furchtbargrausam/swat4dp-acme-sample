# swat4dp
schlag&amp;rahm WebSphere Administration Toolkit for DataPower

## Version: 0.3.0-SNAPSHOT
